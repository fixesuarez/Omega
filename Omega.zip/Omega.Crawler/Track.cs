﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega.Crawler
{
    public class Track
    {
        public string Title { get; set; }
        public string AlbumName { get; set; }
        public string Popularity { get; set; }
        public string Artist { get; set; }
    }
}
