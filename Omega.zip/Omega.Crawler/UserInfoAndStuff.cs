﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega.Crawler
{
    public class UserInfoAndStuff
    {
        public string UserId { get; set; }
        public string Source { get; set; }
        public string TrackId { get; set; }
    }
}
