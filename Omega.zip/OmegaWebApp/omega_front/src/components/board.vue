<template>
  <div>
    <div class=""></div>
  </div>
</template>

<style src="../styles/board.css">
</style>