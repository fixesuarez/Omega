﻿namespace OmegaWebApp.Authentication
{
    public static class JwtBearerAuthentication
    {
        public const string AuthenticationScheme = "OmegaJwtBearer";
    }
}
