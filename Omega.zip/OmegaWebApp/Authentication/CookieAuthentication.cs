﻿namespace OmegaWebApp.Authentication
{
    public static class CookieAuthentication
    {
        public const string AuthenticationScheme = "OmegaCookie";
    }
}
