﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Omega.DAL
{
    public class NewMetadonnees
    {

        public NewMetadonnees()
        {

        }
        public string danceability { get; set; }
        public string energy { get; set; }
        public string loudness { get; set; }
        public string speechiness { get; set; }
        public string accousticness { get; set; }
        public string instrumentalness { get; set; }
        public string liveness { get; set; }
        public string popularity { get; set; }
    }
}
